const db = require('../models');
const JamKerja = db.JamKerja;
const Op = db.Sequelize.Op;
const cron = require('node-cron');

const setAktifJadwal = async () => {       
        try{
            await JamKerja.update({isActive: 0}, {
                where: {
                    isActive : {
                        [Op.eq]: 1
                    }
                }
            });
            await JamKerja.update({isActive: 1}, {where: {
                hari: {
                    [Op.eq]: new Date(Date.now()).getDay()
                }
            }});

        }catch(error){
            return error
        }
}

exports.cronJadwal = (req, res) => {
    try{
        cron.schedule('0 4 * * 1-5', async () => {
            await setAktifJadwal();
        });
    }catch(err){
        console.log(err);
    }
}