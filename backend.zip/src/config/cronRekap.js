/* 
- rekap presensi jam 9 malam
- Jika ada yang belum presensi pulang maka dicatat alpa.
- Jika ada izin yang belum ter acc maka otomatis hapus izin dan set presensi karyawan sesuai presensi yang dilakukan karyawan.
*/

const db = require('../models');
const JamKerja = db.JamKerja;
const Presensi = db.presensi;
const Izin = db.izin;
const Op = db.Sequelize.Op;
const cron = require('node-cron');

const presensiYangHadir = async () => {
    try{
        const presensiMiss = await Presensi.findAll({
            where : {
                [Op.and] : [
                    {
                        jam_pulang : {
                            [Op.eq] : '00:00:00'
                        }
                    },
                    {
                        status : {
                            [Op.eq] : 'hadir'
                        }
                    }
                ]
            },
            raw: true
        });

        if(presensiMiss.length > 0){
            for (const i in presensiMiss) {
                await Presensi.update(
                    {
                        status: 'alpa'
                    }, 
                    {
                        where: {
                            id: presensiMiss[i].id
                        }
                    })
            }
        }

    }catch(error){
        return error;
    }
}

const presensiIzin = async () => {
    try{
        const presensiMiss = await Presensi.findAll({
            where : {
                [Op.and] : [
                    {
                        jam_masuk : {
                            [Op.ne] : '00:00:00'
                        }
                    },
                    {
                        jam_pulang : {
                            [Op.eq] : '00:00:00'
                        }
                    },
                    {
                        status : {
                            [Op.eq] : 'izin'
                        }
                    }
                ]
            },
            raw: true
        });

        if(presensiMiss.length > 0){
            for (const i in presensiMiss) {
                await Presensi.update(
                    {
                        jam_masuk: '00:00:00',
                        status: 'alpa',
                        izinId: null
                    }, 
                    {
                        where: {
                            id: presensiMiss[i].id
                        }
                    })
                await Izin.destroy({where: {id: presensiMiss[i].izinId}});    
            }
        }
    }catch(error){
        return error;
    }
}

exports.cronRekapPresensi = () => {
    try{
        cron.schedule('0 21 * * 1-5', async () => {
            await presensiYangHadir();
            await presensiIzin();
        });
    }catch(err){
        console.log(err);
    }
}