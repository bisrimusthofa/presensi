const db = require('../models/index');
const User = db.user;
const JenisIzin = db.jenis_izin;
const Izin = db.izin;
const Presensi = db.presensi;
const Role = db.role;
const JamKerja = db.JamKerja;
const Op = db.Sequelize.Op;
const jwt = require("jsonwebtoken");
const dateFormat = require('../utils/convertDate');
const compareTime = require('../config/compareTime');

exports.setUser = async (userId, userSocketId) => {
    try{
        const data = await User.update(
                            {
                                socketId: userSocketId
                            },
                            {
                                where: {
                                    id: userId
                                }
                            }
                        );
        return data;
    }catch(err){
        console.log(err)
        return false;
    }
}

exports.getAdmin = async () => {
    try{
        const data = await User.findAll({
            raw: true,
            include: [{
                model: Role,
                as: 'role',
                where: {
                    nama_role: {
                        [Op.substring]: 'Admin'
                    }
                }
            }]
        });
        return data;
    }catch(err){
        console.log(err)
        return false;
    }
}